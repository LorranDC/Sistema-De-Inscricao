class Aluno {

    constructor() {
        this.id = 1;
        this.globalAlunos = [];
        this.editId = null;
    
    }

    inscrever() {
        let aluno = this.lerDados();

        if (this.validaCampos(aluno)) {
            if(this.editId == null) {
            this.adicionar(aluno);
            }
            else {
                this.atualizar(this.editId, aluno);
            }
        }
            
    this.listaTabela();
    this.cancelar();
        
    }

    listaTabela() {
        let tbody = document.getElementById('tbody');
        tbody.innerText = '';

        for(let i =0; i < this.globalAlunos.length; i++) {
            let tr = tbody.insertRow();

            let td_id = tr.insertCell();
            let td_nome = tr.insertCell();
            let td_curso = tr.insertCell();
            let td_editar = tr.insertCell();
            let td_apagar = tr.insertCell();

            td_id.innerText = this.globalAlunos[i].id;
            td_nome.innerText = this.globalAlunos[i].nomeAluno;
            td_curso.innerText = this.globalAlunos[i].cursoAluno;
                            
            let btnEdit = document.createElement('button');
            btnEdit.appendChild(document.createTextNode('editar'));
            btnEdit.setAttribute("onclick", "aluno.preparaEdicao("+JSON.stringify(this.globalAlunos[i])+")");
            btnEdit.setAttribute('id', 'btn-editar');
            btnEdit.setAttribute('class', 'btn-primary');


            let btnDel = document.createElement('button');
            btnDel.appendChild(document.createTextNode('apagar'));
            btnDel.setAttribute("onclick", "aluno.deletar("+this.globalAlunos[i].id+")");
            btnDel.setAttribute('id', 'btn-apagar');
            btnDel.setAttribute('class', 'btn-primary');
            

            td_editar.appendChild(btnEdit);
            td_apagar.appendChild(btnDel);

            console.log(this.globalAlunos);

        }
    }

    adicionar(aluno) {
        this.globalAlunos.push(aluno);
        this.id++;
    }

    atualizar(id, aluno) {
        for (let i = 0; i < this.globalAlunos.length; i++) {
            if(this.globalAlunos[i].id == id) {
                this.globalAlunos[i].nomeAluno = aluno.nomeAluno;
                this.globalAlunos[i].cursoAluno = aluno.cursoAluno;
            }
        }
    }

    preparaEdicao(dados) {
        this.editId = dados.id;

        document.getElementById('nome').value = dados.nomeAluno;
        document.getElementById('curso').value = dados.cursoAluno;

        document.getElementById('btn').innerText = 'Atualizar';
        
    }

    lerDados() {
        let aluno = {}

        aluno.id = this.id;
        aluno.nomeAluno = document.getElementById('nome').value;
        aluno.cursoAluno = document.getElementById('curso').value;

        return aluno;
    }

    validaCampos(aluno) {
        let msg = '';

        if(aluno.nomeAluno == '') {
            msg += '- Informe o nome do Aluno \n';
        }

        if(aluno.cursoAluno == '') {
            msg += '- Informe o curso do Aluno \n';
        }   

        if(msg != '') {
            alert(msg);
            return false
        }

        return true;

    }

    deletar(id) {
        if(confirm('Tem certeza em deletar o Aluno do ID ' +id+'?')) {
            let tbody = document.getElementById('tbody');

            for(let i = 0; i < this.globalAlunos.length; i++) {
                if(this.globalAlunos[i].id == id) {
                    this.globalAlunos.splice(i, 1);
                    tbody.deleteRow(i);
                }
            }
        }
    } 

    cancelar() {
        document.getElementById('nome').value = '';
        document.getElementById('curso').value = '';

        document.getElementById('btn').innerText = 'Inscrever';
        this.editId = null;
        
    }
        

}
var aluno = new Aluno();

